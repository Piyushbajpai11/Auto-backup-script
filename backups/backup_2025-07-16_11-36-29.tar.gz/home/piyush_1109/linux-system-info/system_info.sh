#!/bin/bash

OUTPUT="system_report.txt"
exec > >(tee -a "$OUTPUT") 2>&1  #output to both screen and file 

#colour variables
GREEN='\e[32m'
BLUE='\e[34m'
YELLOW='\e[33m'
CYAN='\e[36m'
RED='\e[31m'
RESET='\e[0m'


echo -e "${RED}-------------------------------------------"
echo -e "🔧 ${YELLOW}System Information Report${RESET}"
echo -e "${BLUE}Generated on: $(date)"
echo -e "${RED}-------------------------------------------${RESET}"

echo -e "🖥️ ${CYAN}Hostname     :${RESET} $(hostname)"
echo -e "👤 ${CYAN}Current User :${RESET} $USER"
echo -e "💽 ${CYAN}OS & Kernel  :${RESET} $(uname -srvmo)"
echo -e "🕒 ${CYAN}Uptime       :${RESET} $(uptime -p)"

echo -e "${YELLOW}🧠 Memory Usage:${RESET}"
free -h | awk 'NR==1 || NR==2'

echo -e "${YELLOW}💾 Disk Usage:${RESET}"
df -h | grep '^/dev/'

echo -e "${CYAN}📡 IP Address   :${RESET} $(hostname -I | awk '{print $1}')"
echo -e "${CYAN}⚙️ Running Procs :${RESET} $(ps -e --no-headers | wc -l)"
echo -e "${CYAN}🔐 Last Login   :${RESET} $(last -n 1 $USER | head -n 1)"

echo -e "${RED}------------------------------------------${RESET}"
