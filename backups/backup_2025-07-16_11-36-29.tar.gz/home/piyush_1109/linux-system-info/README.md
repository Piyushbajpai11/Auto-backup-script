# 🔧 Linux System Info Fetcher

A simple and colorful Bash script that generates a system information report including memory, disk, CPU, and login details.

## 📂 Features

- OS and Kernel Version
- Hostname and Current User
- Uptime
- Memory and Disk Usage
- IP Address
- Running Processes
- Last Login Info
- Saves output to `system_report.txt`
- Colorful terminal output using ANSI escape codes

## 🚀 Usage

```bash
chmod +x system_info.sh
./system_info.sh
```

## 📁 Output

A sample output is saved in system_report.txt every time the script is run.

## 📦 Future Improvements

  - HTML/Markdown formatted reports
  - .deb package support for installation
  - CLI flags for different modes

## Author

  Your Name - Piyush Bajpai
